# Random Simulation Package

This is package for random simulation. It features the Normal ('normal'), Poisson ('poisson') and Binomial ('binom') distributions.

It has both a function and a class. The function returns the random numbers, the number of which can be specified
as an argument. The class has one method that returns the random numbers (the number of which can be specified
as an argument) and another method that prints statistics of the random numbers.

The package can be installed by running

python3 -m pip install --index-url https://test.pypi.org/simple/ random_simulation

